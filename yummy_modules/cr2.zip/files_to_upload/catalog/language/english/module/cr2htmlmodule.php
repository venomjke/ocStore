<?php
// Heading
$_['heading_title']  = 'CR2 HTML Module';
?>
